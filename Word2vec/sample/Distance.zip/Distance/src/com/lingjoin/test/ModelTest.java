package com.lingjoin.test;

import java.util.Map.Entry;

import edu.pan.deepLearning.word2vec.Distance;

public class ModelTest {

	public static void main(String[] args){
		String model=new String("./POS-CBOW.dat");
		Distance dis=new Distance(100,model,true);
		dis.calculateDistanceWithPOS("中国");
		for(Entry<String,Float> entry:dis.getResultMap().entrySet()){
			System.out.println(entry.getKey()+":\t"+entry.getValue());
		}
	}
}
